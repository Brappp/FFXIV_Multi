﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace FFXIVClientManager.Models
{
    /// <summary>
    /// Stores application settings and configuration
    /// </summary>
    public class LauncherSettings
    {
        // Path to XIVLauncher executable
        public string XIVLauncherPath { get; set; } = "";

        // Path for storing backups
        public string BackupPath { get; set; } = "";

        // Path for log files
        public string LogPath { get; set; } = "";

        // Whether to include plugins in backups
        public bool BackupPlugins { get; set; } = true;

        // Whether to restore plugins from backups
        public bool RestorePlugins { get; set; } = true;

        // Default delay between launching multiple clients (seconds)
        public int DefaultLaunchDelay { get; set; } = 30;

        // Maximum number of backups to keep per profile
        public int MaxBackupsPerProfile { get; set; } = 5;

        // Whether to automatically check for XIVLauncher updates
        public bool CheckForUpdates { get; set; } = true;

        // Whether to minimize to system tray
        public bool MinimizeToTray { get; set; } = false;

        // Whether to show a confirmation dialog when closing the application
        public bool ConfirmOnClose { get; set; } = true;

        // Whether to automatically create backups before launching clients
        public bool AutoBackupBeforeLaunch { get; set; } = false;

        // Whether to automatically create backups when clients exit
        public bool AutoBackupAfterExit { get; set; } = false;

        // Whether to show tooltips in the UI
        public bool ShowTooltips { get; set; } = true;

        // Theme setting (Light, Dark, System)
        public string Theme { get; set; } = "System";

        // Whether to start with Windows
        public bool StartWithWindows { get; set; } = false;

        // Whether to check for running instances before launching
        public bool CheckForRunningInstances { get; set; } = true;

        // Get the settings file path
        private string SettingsFilePath
        {
            get
            {
                var appDataPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "FFXIVClientManager");

                if (!Directory.Exists(appDataPath))
                    Directory.CreateDirectory(appDataPath);

                return Path.Combine(appDataPath, "settings.json");
            }
        }

        /// <summary>
        /// Load settings from file
        /// </summary>
        public void LoadSettings()
        {
            try
            {
                if (File.Exists(SettingsFilePath))
                {
                    var json = File.ReadAllText(SettingsFilePath);
                    var settings = JsonConvert.DeserializeObject<LauncherSettings>(json);

                    if (settings != null)
                    {
                        // Copy all settings from the loaded file
                        XIVLauncherPath = settings.XIVLauncherPath;
                        BackupPath = settings.BackupPath;
                        LogPath = settings.LogPath;
                        BackupPlugins = settings.BackupPlugins;
                        RestorePlugins = settings.RestorePlugins;
                        DefaultLaunchDelay = settings.DefaultLaunchDelay;
                        MaxBackupsPerProfile = settings.MaxBackupsPerProfile;
                        CheckForUpdates = settings.CheckForUpdates;
                        MinimizeToTray = settings.MinimizeToTray;
                        ConfirmOnClose = settings.ConfirmOnClose;
                        AutoBackupBeforeLaunch = settings.AutoBackupBeforeLaunch;
                        AutoBackupAfterExit = settings.AutoBackupAfterExit;
                        ShowTooltips = settings.ShowTooltips;
                        Theme = settings.Theme;
                        StartWithWindows = settings.StartWithWindows;
                        CheckForRunningInstances = settings.CheckForRunningInstances;
                    }
                }

                // Set default values for empty paths
                if (string.IsNullOrEmpty(BackupPath))
                {
                    BackupPath = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                        "FFXIVClientManager", "Backups");
                }

                if (string.IsNullOrEmpty(LogPath))
                {
                    LogPath = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                        "FFXIVClientManager", "Logs");
                }

                // Ensure directories exist
                if (!Directory.Exists(BackupPath))
                    Directory.CreateDirectory(BackupPath);

                if (!Directory.Exists(LogPath))
                    Directory.CreateDirectory(LogPath);
            }
            catch (Exception ex)
            {
                // Use defaults if loading fails
                Console.WriteLine($"Error loading settings: {ex.Message}");
            }
        }

        /// <summary>
        /// Save settings to file
        /// </summary>
        public void SaveSettings()
        {
            try
            {
                var json = JsonConvert.SerializeObject(this, Formatting.Indented);
                File.WriteAllText(SettingsFilePath, json);
            }
            catch (Exception ex)
            {
                // Failed to save settings
                Console.WriteLine($"Error saving settings: {ex.Message}");
            }
        }

        /// <summary>
        /// Reset settings to defaults
        /// </summary>
        public void ResetToDefaults()
        {
            XIVLauncherPath = "";
            BackupPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "FFXIVClientManager", "Backups");
            LogPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "FFXIVClientManager", "Logs");
            BackupPlugins = true;
            RestorePlugins = true;
            DefaultLaunchDelay = 30;
            MaxBackupsPerProfile = 5;
            CheckForUpdates = true;
            MinimizeToTray = false;
            ConfirmOnClose = true;
            AutoBackupBeforeLaunch = false;
            AutoBackupAfterExit = false;
            ShowTooltips = true;
            Theme = "System";
            StartWithWindows = false;
            CheckForRunningInstances = true;
        }
    }
}